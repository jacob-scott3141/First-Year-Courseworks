#!/bin/bash

if [ -f $1 ]
then
	numreviews=$(grep -c "<Author>" $1) 
	name=$(basename $1 | sed -r 's/.*\///;s/.dat$//')
	echo $name $numreviews
elif [ -d $1 ]
then
	for filename in $1/*.dat
	do
		$0 $filename
	done | sort -nrk 2
fi
