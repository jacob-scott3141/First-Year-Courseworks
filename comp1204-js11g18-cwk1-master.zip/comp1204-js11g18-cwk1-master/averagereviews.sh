#!/bin/bash

if [ -f $1 ]
then
	score=$(printf "%0.2f" $(awk -v sum=0 -v num=0 '/^<Overall>/ { split($0,array,">"); sum += array[2]; num++ } END { print (sum / num) }' $1))
	name=$(basename $1 | sed -r 's/.*\///' | sed -r 's/.dat$//')
	echo $name $score
elif [ -d $1 ]
then
	for filename in $1/*.dat
	do
		$0 $filename
	done | sort -nrk 2
fi
