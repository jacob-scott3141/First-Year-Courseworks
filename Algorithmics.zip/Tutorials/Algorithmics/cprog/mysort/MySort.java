import java.io.*;
import java.util.*;

public class MySort
{
    public static void main(String [] args )
    {
    		MySort s = new MySort();
    		s.init(5000);
    		s.init(50000);
    		s.init(500000);
    		s.init(5000000);
			s.init(50000000);
    }

    public void init(int n)
    {
    	GraphTime gt = new GraphTime();

		int N = n;
		double[] data = new double[N];
		for (int i=0; i<N; i++)
		    data[i] = Math.random();

		gt.startTimer();
		Arrays.sort(data);
		gt.stopTimer();
		//for (double d: data)
		//    System.out.println(d);
		System.out.println("Time taken for " + n + " = " + gt.getTime());
    }
}

class GraphTime{
  long timePrev;
  double timeTotal;
  int nodes;

  public void startTimer(){
    timePrev = System.nanoTime();
  }

  public void stopTimer(){
    timeTotal = (System.nanoTime() - timePrev)/1000000000.0;
  }

  public double getTime(){
  	return timeTotal;
  }
}