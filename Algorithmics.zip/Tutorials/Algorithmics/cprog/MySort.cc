#include <iostream>
#include <fstream>
#include <iterator>
#include <vector>
#include <algorithm>
#include <iostream>
#include <stdio.h>
#include <chrono>

using namespace std;
using namespace std::chrono;

int main(int argc, char *argv[])
{
  int N;
  sscanf(argv[1], "%d", &N);
  vector<double> data(N);
  for(unsigned int i=0; i<N; i++) {
    data[i] = rand()/(RAND_MAX+1.0);
  }
  auto t = high_resolution_clock::now();
  sort(data.begin(), data.end());
  auto stop = high_resolution_clock::now();
  auto duration = duration_cast<nanoseconds>(stop - t);
  cout << duration.count() << endl;
  //copy(data.begin(), data.end(), ostream_iterator<double>(cout,"\n"));
}