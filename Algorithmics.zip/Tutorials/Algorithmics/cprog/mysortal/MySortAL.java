import java.io.*;
import java.util.*;

public class MySortAL
{
    public static void main(String [] args )
    {
		MySortAL s = new MySortAL();
		s.init(5000);
		s.init(50000);
		s.init(500000);
		s.init(5000000);
		s.init(50000000);
    }

    public void init(int n)
    {
    	GraphTime gt = new GraphTime();
		int N = n;
		List<Double> data = new ArrayList<Double>(N);
		for (int i=0; i<N; i++)
		    data.add(Math.random());
		gt.startTimer();
		Collections.sort(data);
		gt.stopTimer();
		//for (double d: data)
		//    System.out.println(d);
		System.out.println("Time taken for " + n + " = " + gt.getTime());
    }
}

class GraphTime{
  long timePrev;
  double timeTotal;
  int nodes;

  public void startTimer(){
    timePrev = System.nanoTime();
  }

  public void stopTimer(){
    timeTotal = (System.nanoTime() - timePrev)/1000000000.0;
  }

  public double getTime(){
  	return timeTotal;
  }
}