package part1;

import java.util.*;

public class CircularArrayQueue implements MyQueue {
	Integer[] arr = new Integer[10];
	Integer tail = null;
	Integer head = null;
	
	public static void main(String[] args) {
//		CircularArrayQueue t = new CircularArrayQueue();
//		
//		for(int i = 0; i < 12; i++) {
//			t.enqueue(i);
//		}
//		for(int i = 0; i < 9; i++) {
//			t.dequeue();
//		}
//		System.out.println(t.head + " " + t.tail);
//		t.show();
	}
	
	//moves the tail forward and inserts an element there.
	@Override
	public void enqueue(int in) {	
		//if there is no tail, start at 0
		if(tail == null) {
			tail = 0;
			head = 0;
			arr[0] = in;
		}
		//if there are still free spaces
		else if(getCapacityLeft() != 0) {
			//increase tail
			tail++;
			
			//if tail has reached end of list, wrap round to the start
			if(tail == arr.length) {
				tail = 0;
			}
			arr[tail] = in;
		}
		//array is full
		else {
			//create a new array twice the size, copy everything over
			Integer[] sto = new Integer[arr.length*2];
			for(int i = 0; i < arr.length; i++) {
				sto[i] = dequeue();
			}
			//old array = new array
			arr = sto;
			
			//head is now 0, tail is at the end of the old list (halfway through new one)
			head = 0;
			tail = arr.length / 2;
			arr[tail] = in;
		}
		
	}
	
	//used to print all elements of the array
	public void show() {
		for(int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
	}

	//dequeues at the head (overriding from MyQueue)
	@Override
	public int dequeue() throws NoSuchElementException {
		//if array is already empty, can't dequeue
		if(isEmpty()) {
			throw new NoSuchElementException();
		}
		//store whats in the head to return it later
		int sto = arr[head];
		
		//make the current head null, move the head along 1.
		arr[head] = null;
		head++;
		
		//if head has reached end of list, wrap round to the start
		if(head == arr.length) {
			head = 0;
		}
		return sto;
	}
	
	//count number of items in the array
	@Override
	public int noItems() {
		int count = 0;
		for(int i = 0; i < arr.length; i++) {
			if(arr[i] != null) {
				count++;
			}
		}
		return count;
	}
	
	//gets how many more elements can fit in the array
	public int getCapacityLeft() {
		return arr.length - noItems();
	}
	
	//returns true if the array is empty
	@Override
	public boolean isEmpty() {
		if(noItems() == 0) {
			return true;
		}
		return false;
	}

}
