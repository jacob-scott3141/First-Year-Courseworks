package part2;

import java.util.AbstractCollection;
import java.util.Iterator;

public class CircularArrayRing<E> extends AbstractCollection<E> implements Ring<E> {
	int ringSize;
	E[] arr;
	
	public static void main(String[] args) {
		CircularArrayRing<Integer> r = new CircularArrayRing<>(12);
		System.out.println(r.arr.length);
	}
	
	public CircularArrayRing() {
		this(10);		
	}
	
	public CircularArrayRing(int ringSize) {
		this.ringSize = ringSize;
		arr = (E[]) new Object[ringSize];
	}
	
	public boolean add(Object e) {
		return false;
	}
	
	@Override
	public E get(int index) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
