import java.text.DecimalFormat;
import java.math.RoundingMode;
/* extends meter
 * overrides report, if battery meter is assigned, not an electric meter, it will store energy if the total during a cycle is negative.
 * if the total isnt negative, and there are units in the battery, it will use those until it has ran out.
 */
public class BatteryMeter extends Meter{
	//sets the format for rounding to 2 d.p.
	DecimalFormat format = new DecimalFormat("#.##");
	Battery battery = new Battery("Default Battery", 5.0);
	
	//CONSTRUCTOR if called with only name, unit cost, meter reading, and no battery specified, 
	public BatteryMeter(String newUtilityName, double newUnitCost, float newMeterReading) {
		super(newUtilityName, newUnitCost, newMeterReading);
	}
	
	//overloaded constructor, can specify a battery to use instead of default battery
	public BatteryMeter(String newUtilityName, double newUnitCost, float newMeterReading, Battery newBattery) {
		this(newUtilityName, newUnitCost, newMeterReading);
		battery = newBattery;
	}
	
	//Overridden method from meter
	//reports the total cost, taking into account the use of the battery
	public double report(){
		//sets the rounding mode to round up from .5
	    format.setRoundingMode(RoundingMode.HALF_UP);
	    //if total reading is negative, will tell the battery to increase by the positive value of meterReading and reset meterReading to 0
		if(meterReading < 0) {
			battery.addUnits(Math.abs(meterReading));
			meterReading = 0;
		}
		//will try and take units from the battery if possible. battery will return the new meter reading
		else {
			meterReading = battery.takeUnits(meterReading);
		}
		System.out.println("Utility: " + utilityName + "\nMeter Reading: " + meterReading + "\n");
		
		double cost = meterReading * unitCost;
		//formats the cost to 2 d.p.
		System.out.println("Cost for running this unit: \u00a3" + format.format(cost) + "\n");
		
		meterReading = 0f;
		return cost;
	}
	
	//getter for meterReading
	public float getUnits() {
		return meterReading;
	}
}