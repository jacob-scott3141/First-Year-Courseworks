import java.text.DecimalFormat;
import java.math.RoundingMode;
/* superclass of batteryMeter
 * constructor assigns name, unit cost and meter reading
 * has a consumeUnits() method which increases the meter reading
 * has a report method. this tells the user how many units have been used since the last report, and how much this has costed
 */
public class Meter{
	protected String utilityName;
	protected double unitCost;
	protected float meterReading;
	//sets the format for rounding to 2 d.p.
	DecimalFormat format = new DecimalFormat("#.##");

	//constructor, sets string name, double unit cost, float meter reading to start on
	public Meter(String newUtilityName, double newUnitCost, float newMeterReading){
		utilityName = newUtilityName;
		unitCost = newUnitCost;
		meterReading = newMeterReading;
	}
	
	//overloaded constructor, defaults unit cost to 1
	public Meter(String newUtilityName, float newMeterReading){
		utilityName = newUtilityName;
		meterReading = newMeterReading;
		unitCost = 1;
	}
	
	//takes a float for units used as a parameter
	//increases the current meter reading when used
	public void consumeUnits(float unitsUsed){
		meterReading = meterReading + unitsUsed;
	}
	
	//returns the cost used (double) since last report.
	public double report(){
		//sets the rounding mode to round up from .5
	    format.setRoundingMode(RoundingMode.HALF_UP);
		if(meterReading < 0) {
			meterReading = 0;
		}
		
		System.out.println("Utility: " + utilityName + "\nMeter Reading: " + meterReading + "\n");
		
		double cost = meterReading * unitCost;
		System.out.println("Cost for running this unit: \u00a3" + format.format(cost) + "\n##########################################");
		
		meterReading = 0f;
		return cost;
	}
	
	//returns the name of the meter
	public String getName() {
		return utilityName;
	}
}
