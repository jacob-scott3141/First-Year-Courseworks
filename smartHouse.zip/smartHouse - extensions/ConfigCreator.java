import java.util.*;
import java.io.PrintStream;
import java.io.File;

/*ConfigCreator
 * creates a config file based on what information you give it.
 * will then be compatible format with Sim.java. easier than writing your own.
 * to make one: follow on screen instructions when ran
 */
public class ConfigCreator {
	Toolbox toolbox = new Toolbox();
	StringBuilder builder = new StringBuilder();
	PrintStream printStream;
	boolean toContinue = true;
	boolean firstInput = true;
	String name = null;
	String subclass = null;
	String meter = null;
	String minUnits = null;
	String maxUnits = null;
	String fixedUnits = null;		
	String probabilityOn = null;
	String cycleLength = null;
	
	public void run() {
		System.out.println("################CONFIG CREATOR################\n");
		while(toContinue) {
			name = null;
			subclass = null;
			meter = null;
			minUnits = null;
			maxUnits = null;
			fixedUnits = null;		
			probabilityOn = null;
			cycleLength = null;
			System.out.println("What appliance would you like to create? (CyclicFixed: 1, CyclicVaries: 2, RandomFixed: 3, RandomVaries: 4, or to Quit: 5)");
			subclass = toolbox.readStringFromCmd();
			
			//for subclass = cyclicfixed
			
			if(subclass.equals("1")) {
				subclass = "CyclicFixed";
				System.out.println("Name: ");
				
				name = toolbox.readStringFromCmd();
				
				System.out.println("meter: (electric: 1 or water: 2)");
				meter = toolbox.readStringFromCmd();
				//checks valid input
				if(meter.equals("1")) {
					meter = "electric";
				}
				else if(meter.equals("2")) {
					meter = "water";
				}
				else {
					System.out.println("[err] Invalid input for meter");
					meter = null;
				}
				
				System.out.println("Fixed units consumed: (Float, >= 0): ");
				fixedUnits = toolbox.readStringFromCmd();
				
				System.out.println("Cycle length: (format will be x/24. Please input an int for x >= 0)");
				cycleLength = toolbox.readStringFromCmd();
				
				//checks valid input
				try {
					Float.parseFloat(fixedUnits);
				}
				catch(Exception NumberFormatException) {
					System.out.println("[err] Fixed units cannot have a value of \"" + fixedUnits + "\"");
					fixedUnits = null;
				}
				//checks valid input
				try {
					Integer.parseInt(cycleLength);
				}
				catch(Exception NumberFormatException) {
					System.out.println("[err] Cycle length cannot have a value of \"" + cycleLength + "\"");
					cycleLength = null;
				}
				
				//checks values have been assigned
				if(name != null && meter != null && fixedUnits != null && cycleLength != null) {
					//makes sure printstream isnt empty when being created at end
					firstInput = false;
					try{
						this.printStream = new PrintStream(new File("ConfigFile.txt"));
						// will append it to a builder before appending the whole thing to the printstream. prevents overwriting. source: https://www.programcreek.com/java-api-examples/?class=java.io.PrintStream&method=append , Project: r8   File: DexApplication.java
						builder.append("name: " + name + "\r\nsubclass: " + subclass + "\r\nmeter: " + meter + "\r\nFixed units consumed: " + fixedUnits + "\r\nCycle length: " + cycleLength + "/24\r\n\r\n");
					}
					catch(Exception e){
						System.out.println("[err] error occured when creating the config file.");
					}
				}
			}
			
			//for subclass = cyclicvaries
			
			else if(subclass.equals("2")) {
				subclass = "CyclicVaries";
				
				System.out.println("Name: ");
				name = toolbox.readStringFromCmd();
				
				System.out.println("meter: (electric: 1 or water: 2)");
				meter = toolbox.readStringFromCmd();
				//checks valid input
				if(meter.equals("1")) {
					meter = "electric";
				}
				else if(meter.equals("2")) {
					meter = "water";
				}
				else {
					System.out.println("[err] Invalid input for meter");
					meter = null;
				}
				
				System.out.println("Minimum units consumed: (Integer, must be closer to 0 than Max units): ");
				minUnits = toolbox.readStringFromCmd();
				
				System.out.println("Maximum units consumed: (Integer, must be further from 0 than Min units): ");
				maxUnits = toolbox.readStringFromCmd();
				
				System.out.println("Cycle length: (format will be x/24. Please input an int for x >= 0)");
				cycleLength = toolbox.readStringFromCmd();
				
				//checks valid input
				try {
					Integer.parseInt(minUnits);
				}
				catch(Exception NumberFormatException) {
					System.out.println("[err] Min units cannot have a value of \"" + minUnits + "\"");
					minUnits = null;
				}
				//checks valid input
				try {
					Integer.parseInt(maxUnits);
					if(Math.abs(Integer.parseInt(maxUnits)) < Math.abs(Integer.parseInt(minUnits))) {
						System.out.println("[err] Max units (" + maxUnits + ") cannot be closer to zero than Min units (" + minUnits + ")");
					}
				}
				catch(Exception NumberFormatException) {
					System.out.println("[err] Min units cannot have a value of \"" + maxUnits + "\"");
					maxUnits = null;
				}
				
				//checks valid input
				try {
					Float.parseFloat(cycleLength);
				}
				catch(Exception NumberFormatException) {
					System.out.println("[err] Fixed units cannot have a value of \"" + cycleLength + "\"");
					cycleLength = null;
				}
				
				//checks values have beem assigned
				if(name != null && meter != null && minUnits != null && maxUnits != null && cycleLength != null) {
					//makes sure printstream isnt empty when being created at end
					firstInput = false;
					try{
						this.printStream = new PrintStream(new File("ConfigFile.txt"));
						//source: https://www.programcreek.com/java-api-examples/?class=java.io.PrintStream&method=append , Project: r8   File: DexApplication.java
						builder.append("name: " + name + "\r\nsubclass: " + subclass + "\r\nmeter: " + meter + "\r\nMin units consumed: " + minUnits + "\r\nMax units consumed: " + maxUnits + "\r\nCycle length: " + cycleLength + "/24\r\n\r\n");
					}
					catch(Exception e){
						System.out.println("[err] error occured when creating the config file.");
					}
				}
			}
			
			//for subclass = randomfixed
			
			if(subclass.equals("3")) {
				subclass = "RandomFixed";
				
				System.out.println("Name: ");
				name = toolbox.readStringFromCmd();
				
				System.out.println("meter: (electric: 1 or water: 2)");
				meter = toolbox.readStringFromCmd();
				
				//checks valid input
				if(meter.equals("1")) {
					meter = "electric";
				}
				else if(meter.equals("2")) {
					meter = "water";
				}
				else {
					System.out.println("[err] Invalid input for meter");
					meter = null;
				}
				
				System.out.println("Fixed units consumed: (Float, >= 0): ");
				fixedUnits = toolbox.readStringFromCmd();
				
				System.out.println("Probability switched on: (format will be 1 in x. Please input an int for x >= 1)");
				probabilityOn = toolbox.readStringFromCmd();
				
				//checks valid input
				try {
					Float.parseFloat(fixedUnits);
				}
				catch(Exception NumberFormatException) {
					System.out.println("[err] Fixed units cannot have a value of \"" + fixedUnits + "\"");
					fixedUnits = null;
				}
				//checks valid input
				try {
					Integer.parseInt(probabilityOn);
				}
				catch(Exception NumberFormatException) {
					System.out.println("[err] ProbabilityOn cannot have a value of \"" + probabilityOn + "\"");
					probabilityOn = null;
				}
				
				//checks values have been asssigned
				if(name != null && meter != null && fixedUnits != null && probabilityOn != null) {
					//makes sure printstream isnt empty when being created at end
					firstInput = false;
					try{
						this.printStream = new PrintStream(new File("ConfigFile.txt"));
						//source: https://www.programcreek.com/java-api-examples/?class=java.io.PrintStream&method=append , Project: r8   File: DexApplication.java
						builder.append("name: " + name + "\r\nsubclass: " + subclass + "\r\nmeter: " + meter + "\r\nFixed units consumed: " + fixedUnits + "\r\nProbability switched on: 1 in " + probabilityOn + "\r\n\r\n");
					}
					catch(Exception e){
						System.out.println("[err] error occured when creating the config file.");
					}
				}
			}
			
			//for subclass = randomvaries
			
			else if(subclass.equals("4")) {
				subclass = "RandomVaries";
				
				System.out.println("Name: ");
				name = toolbox.readStringFromCmd();
				
				System.out.println("meter: (electric: 1 or water: 2)");
				meter = toolbox.readStringFromCmd();
				
				//checks valid input
				if(meter.equals("1")) {
					meter = "electric";
				}
				else if(meter.equals("2")) {
					meter = "water";
				}
				else {
					System.out.println("[err] Invalid input for meter");
					meter = null;
				}
				
				System.out.println("Minimum units consumed: (Integer, must be closer to 0 than Max units): ");
				minUnits = toolbox.readStringFromCmd();
				
				System.out.println("Maximum units consumed: (Integer, must be further from 0 than Min units): ");
				maxUnits = toolbox.readStringFromCmd();
				
				System.out.println("Probability switched on: (format will be 1 in x. Please input an int for x >= 1)");
				probabilityOn = toolbox.readStringFromCmd();
				
				//checks valid input
				try {
					Integer.parseInt(minUnits);
				}
				catch(Exception NumberFormatException) {
					System.out.println("[err] Min units cannot have a value of \"" + minUnits + "\"");
					minUnits = null;
				}
				//checks valid input
				try {
					Integer.parseInt(maxUnits);
					if(Math.abs(Integer.parseInt(maxUnits)) < Math.abs(Integer.parseInt(minUnits))) {
						System.out.println("[err] Max units (" + maxUnits + ") cannot be closer to zero than Min units (" + minUnits + ")");
					}
				}
				catch(Exception NumberFormatException) {
					System.out.println("[err] Min units cannot have a value of \"" + maxUnits + "\"");
					maxUnits = null;
				}
				
				//checks valid input
				try {
					Integer.parseInt(probabilityOn);
				}
				catch(Exception NumberFormatException) {
					System.out.println("[err] ProbabilityOn cannot have a value of \"" + probabilityOn + "\"");
					probabilityOn = null;
				}
				
				//checks values have been assigned 
				if(name != null && meter != null && minUnits != null && maxUnits != null && probabilityOn != null) {
					//makes sure printstream isnt empty when being created at end
					firstInput = false;
					try{
						this.printStream = new PrintStream(new File("ConfigFile.txt"));
						//source: https://www.programcreek.com/java-api-examples/?class=java.io.PrintStream&method=append , Project: r8   File: DexApplication.java
						builder.append("name: " + name + "\r\nsubclass: " + subclass + "\r\nmeter: " + meter + "\r\nMin units consumed: " + minUnits + "\r\nMax units consumed: " + maxUnits + "\r\nProbability switched on: 1 in " + probabilityOn + "\r\n\r\n");
					}
					catch(Exception e){
						System.out.println("[err] error occured when creating the config file.");
					}
				}
			}
			else if(subclass.equals("5")) {
				System.out.println("Goodbye!");
				
				//doesnt append when builder is null
				if(!firstInput) {
					printStream.append(builder.toString());
				}
				
				toContinue = false;
			}
			
		}
	}
	
	public static void main(String[] args) {
		ConfigCreator cc = new ConfigCreator();
		cc.run();
	}
}
