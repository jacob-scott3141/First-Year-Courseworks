/*CyclicFixed
 * extends appliance
 * when time passed is called, if number of hours running hasnt been exceeded, will consume a fixed amount of energy.
 */

public class CyclicFixed extends Appliance{
	private int timeRunning = 0;
	private float applianceUnitsConsumed;

	//Constructor sets the superconstructor for name, sets float units consumed, and time per day its active
	public CyclicFixed(String newName, float newUnitsConsumed, int newActiveTime){
		super(newName);
		applianceUnitsConsumed = newUnitsConsumed;
		applianceActiveTime = newActiveTime;
		
		//checks that the time is between 0 and 24
		if(applianceActiveTime > 24 || applianceActiveTime < 0){
			System.out.println("Please input an integer active time between 0 and 24");
			applianceActiveTime = 0;
		}
	}
	
	//indicates 1 unit of time has passed.
	public void timePasses(){
		//checks it hasn't been running for longer than it should be
		if(timeRunning < applianceActiveTime){
			System.out.println("time has passed, consumed " + applianceUnitsConsumed + " units.");
			//uses the method from Appliance.java 
			this.tellMeterToConsumeUnits(applianceUnitsConsumed);
		}
		timeRunning++;
		//if timeRunning has reached a day, will reset the time running (as a new day has dawned)
		if(timeRunning >= 24){
			timeRunning = 0;
		}
	}
}