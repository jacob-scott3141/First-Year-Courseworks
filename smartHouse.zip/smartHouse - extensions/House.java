import java.util.*;
import java.math.RoundingMode;
import java.text.DecimalFormat;

/*House
 * contains an arraylist of electric, and an arraylist of water appliances
 * hashset of total appliances (duplicates are removed, hence set)
 * activates all the appliances with activate()
 * ^ , but iterated over the parameter specified in activates(arg)
 * can add an appliance to a list with either addEletricAppliance(appliance) or addWaterAppliance(appliance)
 * can remove an appliance from the house with removeAppliance(appliance)
 * get number of appliances in the house: numAppliances()
 * get meters: getElectricMeter() or getWaterMeter()
 * get total cost: getTotalCost()
 * ^rounds the cost to 2 d.p. and returns the  total cost incurred durting the simulation
 */
public class House{
	Meter waterMeter;
	Meter electricMeter;
	ArrayList<Appliance> electricList = new ArrayList<Appliance>();
	ArrayList<Appliance> waterList = new ArrayList<Appliance>();
	
	double totalCost;
	//sets the format for rounding to 2 d.p.
	DecimalFormat format = new DecimalFormat("#.##");
	
	int numberOfAppliances;
	
	//CONSTRUCTOR sets defualt meters for the house when called with no params
	public House(){
		waterMeter = new Meter("Water", 0.002, 0f);
		electricMeter = new Meter("Electric", 0.013, 0f);
	}
	
	//CONSTRUCTOR sets passed meters for the house
	public House(Meter newElectricMeter, Meter newWaterMeter) {
		waterMeter = newWaterMeter;
		electricMeter = newElectricMeter;
	}
	
	//adds the electric appliance to the elctricList arraylist
	public void addElectricAppliance(Appliance newAppliance){
		electricList.add(newAppliance);
	}
	
	//adds the water appliance to the waterList arraylist
	public void addWaterAppliance(Appliance newAppliance){
		waterList.add(newAppliance);
	}
	
	//takes an appliance to be removved as a parameter
	//removes an appliance from the house
	public void removeAppliance(Appliance removedAppliance){
		Iterator<Appliance> electricIterator = electricList.iterator();
		Iterator<Appliance> waterIterator = electricList.iterator();
		int applianceNumber = 0;

		while(electricIterator.hasNext()){
			Appliance checkAppliance = electricList.get(applianceNumber);

			if(removedAppliance.equals(checkAppliance)){
				electricList.remove(applianceNumber);
				applianceNumber = 0;
				break;
			}
			else{
				applianceNumber++;
			}
		}

		applianceNumber = 0;

		while(waterIterator.hasNext()){
			Appliance checkAppliance = waterList.get(applianceNumber);

			if(removedAppliance.equals(checkAppliance)){
				waterList.remove(applianceNumber);
				applianceNumber = 0;
				break;
			}
			else{
				applianceNumber++;
			}
		}
	}
	
	//combines the sets of appliances (hashsets get rid of duplicates)
	//used mainly to activate appliances 
	//returns the combined hashset
	public HashSet<Appliance> combineSets(){
		Iterator<Appliance> electricIterator = electricList.iterator();
		Iterator<Appliance> waterIterator = waterList.iterator();
		HashSet<Appliance> applianceSet = new HashSet<Appliance>();
		int applianceNumber = 0;

		while(electricIterator.hasNext()){
			applianceSet.add(electricList.get(applianceNumber));
			electricIterator.next();
			applianceNumber++;
		}

		applianceNumber = 0;

		while(waterIterator.hasNext()){
			applianceSet.add(waterList.get(applianceNumber));
			waterIterator.next();
			applianceNumber++;
		}
		
		return applianceSet;
	}
	
	//returns the number of appliances in the house
	public int numAppliances(){
		HashSet<Appliance> applianceSet = this.combineSets();

		int numberOfAppliances = applianceSet.size();

		return numberOfAppliances;
	}

	//prints out all electric appliances
	public void print(){
		for(int i = 0; i < electricList.size(); i++){
			System.out.println(electricList.get(i).getName());
		}
	}
	
	//goes through the hashset of appliances and activates them. adds up the total cost of this report to the total cost
	public void activate() {
		HashSet<Appliance> applianceSet = this.combineSets();
		
		for(Appliance appliance : applianceSet) {
			appliance.timePasses();
		}
		
		totalCost = totalCost + electricMeter.report();
		totalCost = totalCost + waterMeter.report();
	}
	
	//overloaded activate method, activates once for every int(hours) passed  
	//will print out how much it costed total at the end
	public void activate(int hours) {
		for(int hour = 0; hour < hours; hour++) {
			this.activate();
		}
		
		System.out.println(this.getTotalCost());
	}
	
	//getter for the electric meter attached to the house
	public Meter getElectricMeter() {
		return electricMeter;
	}
	
	//getter for the water meter
	public Meter getWaterMeter() {
		return waterMeter;
	}
	
	//getter for total cost. formats the cost to 2 d.p. with DecimalFormat
	public String getTotalCost() {
		//sets the rounding mode to round up from .5
	    format.setRoundingMode(RoundingMode.HALF_UP);
		String printCost = ("Total cost of running: \u00a3" + format.format(totalCost));
		return printCost;
	}
}