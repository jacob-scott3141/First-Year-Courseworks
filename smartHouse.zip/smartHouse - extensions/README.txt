README

To run this simulation:

	#####################################
	javac Sim.java

	java Sim [fileToRun.txt] [time to elapse]	OR	java Sim [fileToRun.txt]	OR	java Sim
	#####################################

	-for cases where no or 1 arg is used, txt file will default to ConfigFile.txt, time will default to 24*7 hours or 1 week.


What has been attempted:

	-all parts of the coursework
	-extensions:
		-ConfigCreator:
			
			#####################################
			javac ConfigCreator.java

			java ConfigCreator

			#####################################

			follow the onscreen instructions to create some appliances, by first selecting a category of appliance: 1,2,3, or 4 (uses the toolbox). when finished, quit using the onscreen instructions ()
			then run the simulation Sim.java (as above), with either no parameters OR with [fileToRun.txt] = "ConfigFile.txt"

 		extensions have not affected the functionality of the original code.

When making a config file normally:

	-category must be followed with a colon, eg name:
	-detail of category must come after the colon, eg :toaster   OR   : toaster   OR   :  toaster   etc
	-first appliance should start at the very top of the page
	-appliances should be seperated by 1 or more blank lines.
	-special categories, like "Probability switched on" and "Cycle length" must be in following format (* represents anything, x represents your value. for prob, * is always a variant of "1 in x". for cycle, * is always a variant of "x / 24")
	
		Probability switched on: *in x    OR    Probability switched on: *inx    OR    Probability switched on: x
	
		Cycle length: x/*    OR    Cycle length: x /*    OR    Cycle length: x
	
	-if any errors are present, you'll see [err] followed by an appropriate error message. 
	-The appliance with the error will not be created.
	-The program will tell you what number appliance the error appears at, and the name of the appliance if there is one.