/*Battery
 * when a batterymeter is attatched to house instead of electric meter, the report method in batterymeter uses a battery.
 * when meterreading is negative, stores energy using addUnits(units)
 * when meterreading is positive, checks if units are in the battery. if there are, will take as many as it needs, and continue as if an appliance has just generated these units.
 * units stored in battery do not exceed max capacity.
 */
public class Battery {
	double currentUnits;
	double maxCapacity;
	private String name;
	
	//constructor takes sting name and a double capacity
	public Battery(String newName, double newCapacity) {
		name = newName;
		maxCapacity = newCapacity;
	}
	
	//addUnits() takes a double of units to add to battery as a parameter
	// - called by battery meter when meterReading < 0.
	public void addUnits(double unitsToAdd) {
		currentUnits = currentUnits + unitsToAdd;
		//makes sure the battery isn't overflowing
		if(currentUnits > maxCapacity) {
			currentUnits = maxCapacity;
		}
	}
	
	//takes double of units to take as a parameter
	//returns the units that will be left in the meter after battery use
	public float takeUnits(double unitsToTake) {
		float unitsLeft;
		
		if(currentUnits >= unitsToTake) {
			currentUnits = currentUnits - unitsToTake;
			unitsLeft = 0f;
		}
		else {
			unitsLeft = (float) (unitsToTake - currentUnits);
			currentUnits = 0;
		}
		
		return unitsLeft;
	}
	
	//getter for name
	public String getName() {
		return name;
	}
	
	//getter for current units
	public double getUnits() {
		return currentUnits;
	}
}
