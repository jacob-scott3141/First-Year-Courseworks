import java.util.Random;
/*RandomFixed
 * extends from appliance
 * adds a probability for the appliance to turn on and a min/max value for consumed units
 */
public class RandomVaries extends Appliance{
	private int probabilityOn;
	private float minUnits;
	private float maxUnits;
	
	//construtor sets the superconstructor for name, sets float max/min units consumed, and probability its active
	public RandomVaries(String newName, float newMinUnits, float newMaxUnits, int newProbabilityOn){
		super(newName);
		probabilityOn = newProbabilityOn;
		minUnits = newMinUnits;
		if(probabilityOn < 1) {
			System.out.println("\nProbability cannot be less than 1 in 1\n");
			probabilityOn = 1;
		}
		//if the appliance primarily generates, MAX should be less than MIN
		if (newMaxUnits < 0 && newMaxUnits <= newMinUnits) {
			maxUnits = newMaxUnits;
		}
		//if the appliance primarily consumes, MAX should be greater than MIN
		else if(newMaxUnits > 0 && newMaxUnits >= newMinUnits) {
			maxUnits = newMaxUnits;
		}
		else {
			System.out.println("\nAbsolute value of Max Units cannot be less than absolute value of Min Units\n");
		}
	}
	
	//indicates 1 unit of time has passed.
	public void timePasses(){
		Random random = new Random();
		float randomUnits;
		// 1 + ... because java.util.Random is exclusive 
		int randomSwitch = 1 + random.nextInt(probabilityOn);
		
		// if appliance consumes, random number is minUnits + (random float between 0 and 1) * (difference of max and min units)
		if(maxUnits >= minUnits) {
			randomUnits = minUnits + random.nextFloat() * (maxUnits - minUnits);
		}
		// if appliance generates, random number is maxUnits + (random float between 0 and 1) * (difference of min and max units)
		else {
			randomUnits = maxUnits + random.nextFloat() * (minUnits - maxUnits);
		}
		
		//if the switch is equal to the probability on (chance of 1 / probabilityOn), will turn on
		if(randomSwitch == probabilityOn) {
			System.out.println("time has passed, consumed " + randomUnits + " units.");
			this.tellMeterToConsumeUnits(randomUnits);
		}		
	}
}