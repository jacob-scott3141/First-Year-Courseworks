import java.util.Random;
/*RandomFixed
 * extends from appliance
 * adds a probability for the appliance to turn on instead of a defined cycle time
 */
public class RandomFixed extends Appliance{
	private float applianceUnitsConsumed;
	private int probabilityOn;
	
	//construtor sets the superconstructor for name, sets float units consumed, and probability its active
	public RandomFixed(String newName, float newUnitsConsumed, int newProbabilityOn){
		super(newName);
		applianceUnitsConsumed = newUnitsConsumed;
		probabilityOn = newProbabilityOn;
		
		if(probabilityOn < 1) {
			System.out.println("\nProbability cannot be less than 1 in 1\n");
			probabilityOn = 1;
		}
	}

	public void timePasses(){
		Random random = new Random();
		// 1 + ... because java.util.Random is exclusive. e.g. random.nextInt(5) will give either 0,1,2,3, or 4
		int randomSwitch = 1 + random.nextInt(probabilityOn);
		
		//if the switch is equal to the probabilityOn (chance of 1 / probabilityOn), will turn on
		if(randomSwitch == probabilityOn) {
			System.out.println("time has passed, consumed " + applianceUnitsConsumed + " units.");
			this.tellMeterToConsumeUnits(applianceUnitsConsumed);
		}		
	}
}