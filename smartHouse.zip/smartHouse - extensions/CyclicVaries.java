import java.util.Random;

/*CyclicVaries
 * extends appliance
 * when time passed is called, if number of hours running hasnt been exceeded, will consume an amount of energy in range min to max.
 */
public class CyclicVaries extends Appliance{
	private int timeRunning = 0;
	private float minUnits;
	private float maxUnits;

	//construtor sets the superconstructor for name, sets float min/maxunits consumed, and time per day its active
	public CyclicVaries(String newName, float newMinUnits, float newMaxUnits, int newActiveTime){
		super(newName);
		applianceActiveTime = newActiveTime;
		minUnits = newMinUnits;
		
		//formatting for max and min units (in future, use math.abs())
		
		//if the appliance primarily generates, MAX should be less than MIN
		if (newMaxUnits < 0 && newMaxUnits <= newMinUnits) {
			maxUnits = newMaxUnits;
		}
		//if the appliance primarily consumes, MAX should be greater than MIN
		else if(newMaxUnits > 0 && newMaxUnits >= newMinUnits) {
			maxUnits = newMaxUnits;
		}
		else {
			System.out.println("\nAbsolute value of Max Units cannot be less than absolute value of Min Units\n");
		}
		
		//checks appropriate active time
		if(applianceActiveTime > 24 || applianceActiveTime < 0){
			System.out.println("Please input an integer active time between 0 and 24");
			applianceActiveTime = 0;
		}
	}
	
	//indicates 1 unit of time has passed.
	public void timePasses(){
		float randomUnits;
		Random random = new Random();
		
		// if appliance consumes, random number is minUnits + (random float between 0 and 1) * (difference of max and min units)
		if(maxUnits >= minUnits) {
			randomUnits = minUnits + random.nextFloat() * (maxUnits - minUnits);
		}
		// if appliance generates, random number is maxUnits + (random float between 0 and 1) * (difference of min and max units)
		else {
			randomUnits = maxUnits + random.nextFloat() * (minUnits - maxUnits);
		}
		
		//checks it hasnt been running for longer than it should be
		if(timeRunning < applianceActiveTime){
			System.out.println("time has passed, consumed " + randomUnits + " units.");
			this.tellMeterToConsumeUnits(randomUnits);
		}
		
		timeRunning++;
		
		//if timeRunning has reached a day, will reset the time running (as a new day has dawned)
		if(timeRunning >= 24){
			timeRunning = 0;
		}
	}
}
