/*Simulation
 * Starts the simulation. decides whether args are correct and if to take args
 * creates the meters and the house
 * reads the config file provided or default file (ConfigFile.txt)
 * activates all appliances for the time specified, or 24*7 (default)
 */

public class Sim{
	
	public static void main(String[] args){
		ConfigReader reader;
		int time;
		
		if(args.length > 0){			
			if(args.length > 1){
				//tries to run the simulation with the file and number of hours to run as arguements
				try{
					reader = new ConfigReader(args[0],Integer.parseInt(args[1])) ;
					time = Integer.parseInt(args[1]);
				}
				catch(Exception NumberFormatException){
					System.out.println("[err] 2nd arguement must be an integer. Setting time passed to 0 Hours.");
					reader = new ConfigReader(args[0],0) ;
					time = 0;
					
				}
			}
			//if only 1 arguement is specified, will not activate (hence 0 hours)
			else{
				reader = new ConfigReader(args[0],24*7) ;
				time = 24*7;
			}
		}
		//if nothing is specified, will attempt to open the default config file
		else {
			reader = new ConfigReader("ConfigFile.txt", 24*7) ;
			time = 24*7;
		}
		
		Meter waterMeter = new Meter("Water", 0.002, 0f);
		BatteryMeter batteryMeter = new BatteryMeter("Battery", 0.013, 0);

		House house = new House(batteryMeter, waterMeter);
		
		
		//checks that there is a file to be read
		if(reader.fileIsReady()) {
			//calls the gethouseconfig method from configreader
			reader.getHouseConfig();
			
			//for each appliance in the arrayList<appliance> returned by get houseconfig, tries to set that appliance up with the house meters
			int appliances = reader.getHouseConfig().size() - 1;
			
			for(int i = 0; i <= reader.getHouseConfig().get(appliances).getIndex(); i++) {
				try{
					//if the element returned by setAppliance has an electric meter, it'll add it to the electric meter list
					if(reader.setAppliance(i, house.getElectricMeter(), house.getWaterMeter()).get(0).getMeter().equals(house.getElectricMeter())) {
						house.addElectricAppliance(reader.setAppliance(i, house.getElectricMeter(), house.getWaterMeter()).get(0));
					}
					//if the element returned by setAppliance has a water meter, it'll add it to the water meter list
					if(reader.setAppliance(i, house.getElectricMeter(), house.getWaterMeter()).get(0).getMeter().equals(house.getWaterMeter())) {
						house.addWaterAppliance(reader.setAppliance(i, house.getElectricMeter(), house.getWaterMeter()).get(0));
					}
				}
				catch(Exception IndexOutOfBoundsException) {
					//empty, because if no appliance is created there will be an outofboundsexception.
				}
			}
			house.activate(time);
		}
		
	}
}
