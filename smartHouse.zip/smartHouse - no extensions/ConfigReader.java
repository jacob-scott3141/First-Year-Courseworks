import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;


/*ConfigReader
 * creates a bufferedreader and reads the file passed from cmd
 * uses techniques from lab9 (fileisready(), bufferedreader, filereader, getline())
 * constructor: takes a string and an int, of filename and time passed respectively
 * 
 * methods:
 * getLine() returns a string of a newline read by bufferedreader
 * fileIsReady() returns a Boolean denoting if the file is ready to be read (true if ready)
 * getHouseConfig() returns an arraylist of appliancedetails (consisting of a category, a detail relating to said category, and an index of what appliance the detail is related to)
 * setAppliance() checks through each appliance detail in getHouseConfig(), and creates an appliance for each unique index
 */
public class ConfigReader {
	BufferedReader reader;
	
	//arrayList of all appliance details
	ArrayList<ApplianceDetails> houseConfig = new ArrayList<>();
	//arrayList of a single appliances details
	ArrayList<ApplianceDetails> applianceConfig = new ArrayList<>();
	int applianceIndex;
	
	String fileName;
	int runTime;
	Boolean canRun = true;
	
	/*Constructor for configreader
	 * takes a string for filename and an int for runtime
	 * args are passed from the command line in the main method
	 * tries to open the file passed, otherwise throws Filenotfoundexception
	 */
	public ConfigReader(String arg1,int arg2) {
		fileName = arg1;
		runTime = arg2;
		
		try{
			this.reader = new BufferedReader(new FileReader(fileName));
		}
		catch(Exception FileNotFoundException){
			System.err.println("[err] File \""+ fileName +"\" does not exist.");
			canRun = false;
		}
	}
	
	/*reads and returns a string of each line in the bufferedreader
	 */
	public String getLine(){
		String newLine = null;
		if(this.fileIsReady() && canRun) {
			try{
				newLine = reader.readLine();
			}
			catch(Exception IOException){
				System.err.print("[err] IO error when reading a new line.");
			}
		}
		return newLine;
	}
	
	/*tests for if the file is ready to be read, returns Boolean of true if it is
	 */
	public Boolean fileIsReady(){
		Boolean ready = false;

		//-if the file is ready to be read, returns true. otherwise, throws an error and returns false
		try{
			ready = reader.ready();
		}
		catch(Exception IOException){
			System.err.println("[err] IO error when checking file is ready.");
		}

		return ready;
	}
	
	/* returns an ArrayList of appliance details
	 * skips all empty lines, tags each appliance with an index so that all details of each appliance are self contained
	 */
	public ArrayList<ApplianceDetails> getHouseConfig(){
		String line;
		
		//if there are multiple newlines, will only increase index once
		Boolean isNewLine = true;
		int index = 0;
		
		//skips empty lines
		while((line = this.getLine()) != null) {
			
			//if there is a line break(denoting a new appliance being made), will tag all appliance details with a different index)
			if(line.equals("")) {
				//if there is a new line denoting a new appliance
				if(isNewLine == true) {
					index++;
				}
				//if the blank line is after a newline, index wont increase
				isNewLine = false;
			}
			//if there is no break, will split the line by ":"
			else {
				String[] categoryDetailSplit = line.split(":");
				
				try {
					//if the categoryDetailSplit has a second index (ie, has a category with a detail provided), will create and add an appliancedetail to the arrayList
					if(!categoryDetailSplit[1].substring(1).equals("")) {
						String category = categoryDetailSplit[0];
						String details = categoryDetailSplit[1];
						
						//removes all spaces before a detail
						for(int iterator = 1; iterator < categoryDetailSplit[1].length(); iterator++) {
							if(categoryDetailSplit[1].substring(iterator-1,iterator).equals(" ")) {
								//if the format has some spaces, ie name:   toaster, will remove the "   "
								details = categoryDetailSplit[1].substring(iterator);
							}
							else {
								//breaks when no more spaces are found
								break;
							}
						}
						
						ApplianceDetails temporaryApplianceDetails = new ApplianceDetails(category, details, index);
						houseConfig.add(temporaryApplianceDetails);
					}
				}
				catch(Exception ArrayIndexOutOfBoundsException) {
					//if no second index is provided, doesn't add to the arraylist and continues looping
				}
				
				isNewLine = true;
			}
		}
		return houseConfig;
	}
	
	/*takes an integer for the appliance that you want to add to the arraylist of appliances and both meters of the house
	 * (each appliancedetail is tagged with an index to denote whether or not its a new appliance)
	 * returns a list containing a singleton of the appliance created. will be empty if no appliance is created
	 */
	public ArrayList<Appliance> setAppliance(int index, Meter electric, Meter water){
		//makes a list of both appliance categories and details
		ArrayList<ApplianceDetails> bothList = new ArrayList<>();
		//makes a list which will contain an appliance if one is made to be returned
		ArrayList<Appliance> applianceList = new ArrayList<>();
		
		Appliance tempAppliance;
		
		String name = null;
		String subclass = null;
		String meter = null;
		String minUnits = null;
		String maxUnits = null;
		String fixedUnits = null;		
		String probabilityOn = null;
		String cycleLength = null;
		int probability = 0;
		int cycle = 0;
		int min = 0;
		int max = 0;
		float fixed = 0;
		
		//creates an errorlist which will be iterated through if any errors are found
		ArrayList<String> errList = new ArrayList<>();
		
		//for every appliance detail in the config file: 
		//if the index is the same as the one passed (ie, the details originate from the same appliance), we add it to bothlist
		for(ApplianceDetails appliance : houseConfig) {
			if(appliance.getIndex() == (index)) {
				bothList.add(appliance);
			}
		}
		
		//for each detail in bothlist, attempts to assign the category with a detail
		for(ApplianceDetails info : bothList) {
			if(info.getCategory().equals("name")) {
				name = info.getDetails();
			}
			
			if(info.getCategory().equals("meter")) {
				meter = info.getDetails();
			}
			
			if(info.getCategory().equals("subclass") && info.getDetails().equals("CyclicFixed") ) {
				subclass = info.getDetails();
			}
			
			
			else if(info.getCategory().equals("subclass") && info.getDetails().equals("CyclicVaries") ) {
				subclass = info.getDetails();
			}
			
			
			else if(info.getCategory().equals("subclass") && info.getDetails().equals("RandomFixed") ) {
				subclass = info.getDetails();
			}
			
			
			else if(info.getCategory().equals("subclass") && info.getDetails().equals("RandomVaries")){
				subclass = info.getDetails();
			}
			
		}
		
		//if nothing is found for name meter or subclass, it will append these to the error list
		if(name == null) {
			errList.add("name");
		}
		if(meter == null) {
			errList.add("meter");
		}
		if(subclass == null){
			subclass = "";
			errList.add("subclass");
		}
		
		/*if the subclass is cyclic fixed, tries to get additional details from bothlist
		 * tries to convert fixed units consumed into a Float
		 * tries to convert cyclelength into int
		 * if all previous variables have been assigned a value, will set up the appliance
		 */
		
		if(subclass.equals("CyclicFixed")) {
			for(ApplianceDetails info : bothList) {
				if(info.getCategory().equals("Fixed units consumed")) {
					fixedUnits = info.getDetails();
					try{
						fixed = Float.parseFloat(fixedUnits);
					}
					catch(Exception NumberFormatException) {
						System.out.println("[err] Incorrect format for Fixed units consumed: " + fixedUnits);
					}
				}
				
				if(info.getCategory().equals("Cycle length")) {
					cycleLength = info.getDetails();
					try{
						//splits the cycle length by / and tries to take the value before "/" as an int cycleLength
						cycle = Integer.parseInt(cycleLength.split("/")[0]);
					}
					catch(Exception e) {
						try {
							//splits the cycle length by / and tries to parse this as an int with format x /24 or x / 24
							cycle = Integer.parseInt(cycleLength.split("/")[0].substring(0, cycleLength.split("/")[0].length() - 1));
						}
						catch(Exception NumberFormatException) {
							System.out.println("[err] Incorrect format for Cycle length");
						}
					}
				}
			}
			
			//if vars have been assigned, will create the class
			if(name != null && fixedUnits != null && cycleLength != null && meter != null)
				try {
					tempAppliance = new CyclicFixed(name, fixed, cycle);
					
					//takes the passed meters and sets them up with the appliance
					if(meter.equals("electric")) {
						tempAppliance.setMeter(electric);
					}
					else if(meter.equals("water")) {
						tempAppliance.setMeter(water);
					}
					applianceList.add(tempAppliance);
				}
			
				catch(Exception e) {
					System.out.println("[err] " + e);
				}
			//if any vars are null, will output an error message and return an empty list
			else {
				if(fixedUnits == null) {
					errList.add("Fixed units consumed");
				}
				if(cycleLength == null) {
					errList.add("Cycle length");
				}
				//if the appliance has a name, will tell the user which appliance is broken. 
				if(name != null) {
					System.out.println("[err] Invalid category names for appliance " + (index + 1) + ": " + name);
				}
				//otherwise, only tells the user the position that appliances appears at
				else {
					System.out.println("[err] Invalid category names for appliance " + (index + 1) + ": ");
				}
				for(String err : errList) {
					System.out.println("    " + err);
				}
				System.out.println();
			}
		}
		
		/*if the subclass is cyclic varies, tries to get additional details from bothlist
		 * tries to convert min/max units consumed into ints
		 * tries to convert cyclelength into int
		 * if all previous vars have been assigned a value, will set up the appliance
		 */
		
		if(subclass.equals("CyclicVaries")) {
			for(ApplianceDetails info : bothList) {
				if(info.getCategory().equals("Min units consumed")) {
					minUnits = info.getDetails();
					try{
						min = Integer.parseInt(minUnits);
					}
					catch(Exception NumberFormatException) {
						System.out.println("[err] Incorrect format for Min units consumed");
					}
				}
				
				if(info.getCategory().equals("Max units consumed")) {
					maxUnits = info.getDetails();
					try{
						max = Integer.parseInt(maxUnits);
					}
					catch(Exception NumberFormatException) {
						System.out.println("[err] Incorrect format for Max units consumed");
					}
				}
				
				if(info.getCategory().equals("Cycle length")) {
					cycleLength = info.getDetails();
					try{
						//splits the cycle length by / and tries to parse this as an int with format x/24
						cycle = Integer.parseInt(cycleLength.split("/")[0]);
					}
					catch(Exception e) {
						try {
							//splits the cycle length by / and tries to parse this as an int with format x /24 or x / 24
							cycle = Integer.parseInt(cycleLength.split("/")[0].substring(0, cycleLength.split("/")[0].length() - 1));
						}
						catch(Exception NumberFormatException) {
							System.out.println("[err] Incorrect format for Cycle length");
						}
					}
				}
			}
			
			//if vars have been assigned, will create the class, like before
			if(name != null && minUnits != null && maxUnits != null && cycleLength != null && meter != null)
				try {
					tempAppliance = new CyclicVaries(name, min, max, cycle);
					if(meter.equals("electric")) {
						tempAppliance.setMeter(electric);
					}
					else if(meter.equals("water")) {
						tempAppliance.setMeter(water);
					}
					applianceList.add(tempAppliance);
				}
				catch(Exception e) {
					System.out.println("[err] " + e);
				}
			//if any have returned null, adds the category to the error list.
			else {
				if(minUnits == null) {
					errList.add("Min units consumed");
				}
				if(maxUnits == null) {
					errList.add("Min units consumed");
				}
				if(cycleLength == null) {
					errList.add("Cycle length");
				}
				//if the appliance has a name, will tell the user which appliance is broken. 
				if(name != null) {
					System.out.println("[err] Invalid category names for appliance " + (index + 1) + ": " + name);
				}
				//otherwise, only tells the user the position that appliances appears at
				else {
					System.out.println("[err] Invalid category names for appliance " + (index + 1) + ": ");
				}
				for(String err : errList) {
					System.out.println("    " + err);
				}
				System.out.println();
			}
		}
		
		/*if the subclass is random fixed, tries to get additional details from bothlist
		 * tries to convert fixed units consumed into floats
		 * tries to convert probability into int, by splitting where the / should be.
		 * if all previous vars have been assigned a value, will set up the appliance
		 */
		
		if(subclass.equals("RandomFixed")) {
			for(ApplianceDetails info : bothList) {
				if(info.getCategory().equals("Fixed units consumed")) {
					fixedUnits = info.getDetails();
					try{
						fixed = Float.parseFloat(fixedUnits);
					}
					catch(Exception NumberFormatException) {
						System.out.println("[err] Incorrect format for Fixed units consumed");
					}
				}
				
				if(info.getCategory().equals("Probability switched on")) {
					probabilityOn = info.getDetails();
					try {
						//gets the 2nd part of the probability (e.g. for 1 in 5, will return 5)
						probabilityOn = probabilityOn.split("in")[1];
					}
					catch(Exception ArrayIndexOutOfBoundsException) {
						//will do nothing. all probabilities are 1 in x, so allows user to just input x.
					}
					
					try {
						// if user writes 1in5 , this won't fail
						probability = Integer.parseInt(probabilityOn);
					}
					catch(Exception e) {
						try {
							//if user inputs 1in 5 or 1 in 5, this wont fail
							probability = Integer.parseInt(probabilityOn.substring(1));
						}
						catch(Exception NumberFormatException) {
							//tells the user about the probability format error
							System.out.println("[err] Incorrect format for probability: "  + probabilityOn + "\n");
							probabilityOn = null;
						}
					}
				}
			}
			
			//creates a class if it has the appropriate formats for all required variables
			if(name != null && fixedUnits != null && probabilityOn != null && meter != null)
				try {
					tempAppliance = new RandomFixed(name, fixed, probability);
					if(meter.equals("electric")) {
						tempAppliance.setMeter(electric);
					}
					else if(meter.equals("water")) {
						tempAppliance.setMeter(water);
					}
					applianceList.add(tempAppliance);
				}
				//Shouldn't have to use this exception, this was used to test unexpected behaviour
				catch(Exception e) {
					System.out.println("[err] " + e);
				}
			//if any variables haven't been assigned, returns an error message to the user
			else {
				if(fixedUnits == null) {
					errList.add("Fixed units consumed");
				}
				if(probabilityOn == null) {
					errList.add("Probability switched on");
				}
				//if the appliance has a name, will tell the user which appliance is broken. 
				if(name != null) {
					System.out.println("[err] Invalid category names for appliance " + (index + 1) + ": " + name);
				}
				//otherwise, only tells the user the position that appliances appears at
				else {
					System.out.println("[err] Invalid category names for appliance " + (index + 1) + ": ");
				}
				for(String err : errList) {
					System.out.println("    " + err);
				}
				System.out.println();
			}
		}
		
		/*if the subclass is cyclic varies, tries to get additional details from bothlist
		 * tries to convert min/max units consumed into ints
		 * tries to convert probability on into int
		 * if all previous variables have been assigned a value, will set up the appliance
		 */
		
		if(subclass.equals("RandomVaries")) {
			for(ApplianceDetails info : bothList) {
				if(info.getCategory().equals("Min units consumed")) {
					minUnits = info.getDetails();
					try{
						min = Integer.parseInt(minUnits);
					}
					catch(Exception NumberFormatException) {
						System.out.println("[err] Incorrect format for Min units consumed");
					}
				}
				
				if(info.getCategory().equals("Max units consumed")) {
					maxUnits = info.getDetails();
					try{
						max = Integer.parseInt(maxUnits);
					}
					catch(Exception NumberFormatException) {
						System.out.println("[err] Incorrect format for Max units consumed");
					}
				}
				
				if(info.getCategory().equals("Probability switched on")) {
					probabilityOn = info.getDetails();
					try {
						//gets the 2nd part of the probability (e.g. for 1 in 5, will return 5)
						probabilityOn = probabilityOn.split("in")[1];
					}
					catch(Exception ArrayIndexOutOfBoundsException) {
						//will do nothing. all probabilities are 1 in x, so allows user to just input x.
					}
					
					try {
						// if user writes 1in5 , this won't fail
						probability = Integer.parseInt(probabilityOn);
					}
					catch(Exception e) {
						try {
							//if user inputs 1in 5 or 1 in 5, this wont fail
							probability = Integer.parseInt(probabilityOn.substring(1));
						}
						catch(Exception NumberFormatException) {
							//tells the user about the probability format error
							System.out.println("[err] Incorrect format for probability: "  + probabilityOn + "\n");
							probabilityOn = null;
						}
					}
				}
			}
			
			//if vars have been assigned, will create the class, like before
			if(name != null && minUnits != null && maxUnits != null && probabilityOn != null && meter != null)
				try {
					tempAppliance = new RandomVaries(name, min, max, probability);
					if(meter.equals("electric")) {
						tempAppliance.setMeter(electric);
					}
					else if(meter.equals("water")) {
						tempAppliance.setMeter(water);
					}
					applianceList.add(tempAppliance);
				}
				catch(Exception e) {
					System.out.println("[err] " + e);
				}
			//if any variables haven't been assigned, returns an error message to the user
			else {
				if(minUnits == null) {
					errList.add("Min units consumed");
				}
				if(maxUnits == null) {
					errList.add("Min units consumed");
				}
				if(probabilityOn == null) {
					errList.add("Probability switched on");
				}
				//if the appliance has a name, will tell the user which appliance is broken. 
				if(name != null) {
					System.out.println("[err] Invalid category names for appliance " + (index + 1) + ": " + name);
				}
				//otherwise, only tells the user the position that appliances appears at
				else {
					System.out.println("[err] Invalid category names for appliance " + (index + 1) + ": ");
				}
				for(String err : errList) {
					System.out.println("    " + err);
				}
				System.out.println();
			}
		}
		
		/*/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		*////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		//if no subclass is assigned, will print out error messages for the 3 categories all appliances have (if present)
		else if(subclass.equals("")){
			
			//if the appliance has a name, will tell the user which appliance is broken. 
			if(name != null) {
				System.out.println("[err] Invalid category names for appliance " + (index + 1) + ": " + name);
			}
			//otherwise, only tells the user the position that appliances appears at
			else {
				System.out.println("[err] Invalid category names for appliance " + (index + 1) + ": ");
			}
			for(String err : errList) {
				System.out.println("    " + err);
			}
		}
		return applianceList;
	}
}











