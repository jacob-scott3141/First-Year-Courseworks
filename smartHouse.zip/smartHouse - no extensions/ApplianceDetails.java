/* Appliance Details
 * used to store a category (e.g. name or sublass) and a detail (e.g. toater or RandomVaries)
 * used basis techniques from Lab9 (splitting up flashcards into questions and answers)
 * 
 * Constructor: takes category, details, and the index of the appliance of which the detail and category are a part of
 */

public class ApplianceDetails {
	String category;
	String details;
	int applianceNumber;
	
	public ApplianceDetails(String newCategory, String newDetails, int applianceNumber) {
		this.category = newCategory;
		this.details = newDetails;
		this.applianceNumber = applianceNumber;
	}
	
	
	//Getter for String category
	public String getCategory(){
		return category;
	}
	
	//Getter for String details
	public String getDetails() {
		return details;
	}
	
	//Getter for int applianceNumber
	public int getIndex() {
		return applianceNumber;
	}
}
