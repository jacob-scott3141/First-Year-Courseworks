public abstract class Appliance{
	protected String applianceName;
	protected int applianceActiveTime;
	private Meter applianceMeter;
	
	//constructor sets the name of the appliance
	public Appliance(String newName){
		applianceName = newName;
		
	}
	
	//sets the meter of the appliance
	public void setMeter(Meter meter){
		applianceMeter = meter;
	}
	
	//abstract method for time passing. different appliances handle this differently
	public abstract void timePasses();
	
	//tells the setMeter to consume units when called
	protected void tellMeterToConsumeUnits(float units){
		applianceMeter.consumeUnits(units);
	}
	
	//getter for the meter
	public Meter getMeter() {
		return applianceMeter;
	}
	
	//getter for the string name
	public String getName(){
		return applianceName;
	}
}
