import java.util.Random;

public class RandomFixed extends Appliance{
	private float applianceUnitsConsumed;
	private int probabilityOn;
	
	//Constructor sets the superconstructor for name, sets float units consumed, and probability its active
	public RandomFixed(String newName, float newUnitsConsumed, int newProbabilityOn){
		super(newName);
		applianceUnitsConsumed = newUnitsConsumed;
		probabilityOn = newProbabilityOn;
	}

	public void timePasses(){
		Random random = new Random();
		// 1 + ... because java.util.Random is exclusive 
		int randomSwitch = random.nextInt(probabilityOn + 1);
		
		//if the switch is equal to the probability on (chance of 1 / probabilityOn), will turn on
		if(randomSwitch == probabilityOn) {
			System.out.println("time has passed, consumed " + applianceUnitsConsumed + " units.");
			this.tellMeterToConsumeUnits(applianceUnitsConsumed);
		}		
	}
}